package com.tech.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.tech.entity.Customer;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
public class ExcelDataController {
	
	@GetMapping("/show")
	public String show() {
//		List <Customer> custList = readXLSXFile("D:\\abc.xlsx");
//		  for(Customer cust : custList){
//		   System.out.println(cust);
//		   cust.getCustName();
//		   
//		   //Customer customer = new Customer();
//		   //customer.setCustName(cust.getCustName());
//		  }
		  
		return "/readdata";
	}
	
	@GetMapping("/gettable")
	public String getdatatable() {		  
		return "/datatable";
	}
	
	@GetMapping("/uploadfile")
	public String uploadFile() {		  
		return "/readuploadfile";
	}
	
	@GetMapping("/Readxl")
	@ResponseBody
	public List <Customer> readxl() {
		List <Customer> custList = readXLSXFile("D:\\abc.xlsx");
//		  for(Customer cust : custList){
//		   System.out.println(cust);
//		   cust.getCustName();
//		  }
		  
		return custList;//"/readdata";
	}
	
	

	
	@PostMapping("/upload") 
  public List<Customer> handleFileUpload( @RequestParam("file") MultipartFile file ) throws IOException 
	{
	    InputStream in = file.getInputStream();
	    File currDir = new File(".");
	    String path = currDir.getAbsolutePath();
	    fileLocation = path.substring(0, path.length() - 1) + file.getOriginalFilename();	    
	    FileOutputStream f = new FileOutputStream(fileLocation);
	    int ch = 0;
	    while ((ch = in.read()) != -1) {
	        f.write(ch);
	    }
	    f.flush();
	    f.close();
	    List<Customer> customerlist = readXLSXFile(file.getOriginalFilename());
	    for(Customer cust : customerlist){
			   System.out.println(cust);
			  }
	    return customerlist;
  }
	
//	@GetMapping("/display")
//	public String display(HttpServletResponse res, HttpServletRequest req ) {
//		
//		req.getParameter("fileupload");
//		
//		List <Customer> custList = readXLSXFile("D:\\abc.xlsx");//("D:\\Test\\CustDetailsXLSX.xlsx");
//		  for(Customer cust : custList){
//		   System.out.println(cust);
//		  }
//		
//		return "/readdata";
//	}

	
	private String fileLocation;

	@PostMapping("/uploadExcelFile")
	public String uploadFile(Model model, MultipartFile file) throws IOException {
	    InputStream in = file.getInputStream();
	    File currDir = new File(".");
	    String path = currDir.getAbsolutePath();
	    fileLocation = path.substring(0, path.length() - 1) + file.getOriginalFilename();
	    
	    	    
	    
	    FileOutputStream f = new FileOutputStream(fileLocation);
	    int ch = 0;
	    while ((ch = in.read()) != -1) {
	        f.write(ch);
	    }
	    f.flush();
	    f.close();
	    model.addAttribute("message", "File: " + file.getOriginalFilename() 
	      + " has been uploaded successfully!");
	    List<Customer> customerlist = readXLSXFile(file.getOriginalFilename());
	    for(Customer cust : customerlist){
			   System.out.println(cust);
			  }
	    return  "readdata";//"excel";
	}	
	
	@PostMapping("/uploadnewFile")
	@ResponseBody
	public List<Customer> uploadExcelFile(Model model, MultipartFile file) throws IOException {
	    InputStream in = file.getInputStream();
	    File currDir = new File(".");
	    String path = currDir.getAbsolutePath();
	    fileLocation = path.substring(0, path.length() - 1) + file.getOriginalFilename();
	    
	    	    
	    
	    FileOutputStream f = new FileOutputStream(fileLocation);
	    int ch = 0;
	    while ((ch = in.read()) != -1) {
	        f.write(ch);
	    }
	    f.flush();
	    f.close();
	    model.addAttribute("message", "File: " + file.getOriginalFilename() 
	      + " has been uploaded successfully!");
	    List<Customer> customerlist = readXLSXFile(file.getOriginalFilename());
	    for(Customer cust : customerlist){
			   System.out.println(cust);
			  }
	    return  customerlist;
	}
	
	private static List<Customer> readXLSXFile(String file) {
		  List<Customer> listCust = new ArrayList<Customer>();
		  try {
		   XSSFWorkbook work = new XSSFWorkbook(new FileInputStream(file));
		   
		   XSSFSheet sheet = work.getSheet("Sheet1");
		   XSSFRow row = null;
		   int i=0;
		   row = sheet.getRow(i);
		   if(row != null)
		   while((row = sheet.getRow(i))!=null){
		    int custId,pinCode;
		    String custName,custCity,stateCode;
		    try{
		     custId = (int) row.getCell(0).getNumericCellValue();
		    }
		    catch(Exception e){custId = 0;}
		    try{
		     custName = row.getCell(1).getStringCellValue();
		    }
		    catch(Exception e){custName = null;}
		    try{
		     custCity = row.getCell(2).getStringCellValue();
		    }
		    catch(Exception e){custCity = null;}
		    try{
		     pinCode = (int) row.getCell(3).getNumericCellValue();
		    }
		    catch(Exception e){pinCode = 0;}
		    try{
		     stateCode = row.getCell(4).getStringCellValue();
		    }
		    catch(Exception e){stateCode = null;}
		    Customer cust = new Customer(custId,custName,custCity,pinCode,stateCode);
		    listCust.add(cust);
		     i++;    
		   }
		   work.close();
		  } catch (IOException e) {
		   System.out.println("Exception is Customer fetch data :: "+e.getMessage());
		   e.printStackTrace();
		  }
		  return listCust;
		 } 	


}
